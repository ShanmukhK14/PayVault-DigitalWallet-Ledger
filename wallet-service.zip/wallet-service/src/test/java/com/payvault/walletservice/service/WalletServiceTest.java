package com.payvault.walletservice.service;

import com.payvault.walletservice.entity.Wallet;
import com.payvault.walletservice.entity.WalletStatus;
import com.payvault.walletservice.exception.InsufficientFundsException;
import com.payvault.walletservice.repository.WalletRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/** Pure unit tests: no Spring context, no database. Good template for the other services. */
@ExtendWith(MockitoExtension.class)
class WalletServiceTest {

    @Mock
    private WalletRepository repository;

    @InjectMocks
    private WalletService service;

    private Authentication user(String name) {
        return new UsernamePasswordAuthenticationToken(name, null, List.of(new SimpleGrantedAuthority("ROLE_USER")));
    }

    private Authentication admin() {
        return new UsernamePasswordAuthenticationToken("root", null, List.of(new SimpleGrantedAuthority("ROLE_ADMIN")));
    }

    private Wallet wallet(Long id, String owner, String balance) {
        Wallet w = new Wallet(owner, new BigDecimal(balance));
        w.setId(id);
        return w;
    }

    @Test
    void credit_increasesBalance() {
        Wallet w = wallet(1L, "alice", "100.00");
        when(repository.findByIdForUpdate(1L)).thenReturn(Optional.of(w));
        when(repository.save(any(Wallet.class))).thenAnswer(inv -> inv.getArgument(0));

        Wallet result = service.credit(1L, new BigDecimal("50.00"));

        assertEquals(0, new BigDecimal("150.00").compareTo(result.getBalance()));
    }

    @Test
    void debit_byOwner_decreasesBalance() {
        Wallet w = wallet(1L, "alice", "100.00");
        when(repository.findByIdForUpdate(1L)).thenReturn(Optional.of(w));
        when(repository.save(any(Wallet.class))).thenAnswer(inv -> inv.getArgument(0));

        Wallet result = service.debit(1L, new BigDecimal("30.00"), user("alice"));

        assertEquals(0, new BigDecimal("70.00").compareTo(result.getBalance()));
    }

    @Test
    void debit_moreThanBalance_throwsAndDoesNotSave() {
        Wallet w = wallet(1L, "alice", "20.00");
        when(repository.findByIdForUpdate(1L)).thenReturn(Optional.of(w));

        assertThrows(InsufficientFundsException.class,
                () -> service.debit(1L, new BigDecimal("50.00"), user("alice")));

        verify(repository, never()).save(any(Wallet.class));
        assertEquals(0, new BigDecimal("20.00").compareTo(w.getBalance()));
    }

    @Test
    void debit_byAnotherUser_isForbidden() {
        Wallet w = wallet(1L, "alice", "100.00");
        when(repository.findByIdForUpdate(1L)).thenReturn(Optional.of(w));

        assertThrows(AccessDeniedException.class,
                () -> service.debit(1L, new BigDecimal("10.00"), user("mallory")));

        verify(repository, never()).save(any(Wallet.class));
    }

    @Test
    void debit_onSuspendedWallet_isRejected() {
        Wallet w = wallet(1L, "alice", "100.00");
        w.setStatus(WalletStatus.SUSPENDED);
        when(repository.findByIdForUpdate(1L)).thenReturn(Optional.of(w));

        assertThrows(IllegalStateException.class,
                () -> service.debit(1L, new BigDecimal("10.00"), user("alice")));
    }

    @Test
    void create_whenWalletAlreadyExists_isRejected() {
        when(repository.existsByOwnerUsername("alice")).thenReturn(true);

        assertThrows(IllegalStateException.class, () -> service.create(user("alice"), null));

        verify(repository, never()).save(any(Wallet.class));
    }

    @Test
    void delete_withRemainingBalance_isRejected() {
        Wallet w = wallet(1L, "alice", "5.00");
        when(repository.findById(1L)).thenReturn(Optional.of(w));

        assertThrows(IllegalStateException.class, () -> service.delete(1L, user("alice")));

        verify(repository, never()).delete(any(Wallet.class));
    }

    @Test
    void list_forNormalUser_returnsOnlyOwnWallet() {
        Wallet w = wallet(1L, "alice", "10.00");
        when(repository.findByOwnerUsername("alice")).thenReturn(Optional.of(w));

        List<Wallet> result = service.list(user("alice"));

        assertEquals(1, result.size());
        assertEquals("alice", result.get(0).getOwnerUsername());
        verify(repository, never()).findAll();
    }

    @Test
    void list_forAdmin_returnsEverything() {
        when(repository.findAll()).thenReturn(List.of(wallet(1L, "alice", "1.00"), wallet(2L, "bob", "2.00")));

        assertEquals(2, service.list(admin()).size());
    }
}
