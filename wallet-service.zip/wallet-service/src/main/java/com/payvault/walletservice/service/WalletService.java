package com.payvault.walletservice.service;

import com.payvault.walletservice.entity.Wallet;
import com.payvault.walletservice.entity.WalletStatus;
import com.payvault.walletservice.exception.InsufficientFundsException;
import com.payvault.walletservice.exception.WalletNotFoundException;
import com.payvault.walletservice.repository.WalletRepository;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Service
public class WalletService {

    private final WalletRepository repository;

    public WalletService(WalletRepository repository) {
        this.repository = repository;
    }

    // ---------------------------------------------------------------- CRUD

    /** The wallet is always created for the user in the token, never for a name sent in the body. */
    @Transactional
    public Wallet create(Authentication auth, BigDecimal initialBalance) {
        String owner = auth.getName();
        if (repository.existsByOwnerUsername(owner)) {
            throw new IllegalStateException("Wallet already exists for user " + owner);
        }
        BigDecimal start = initialBalance == null ? BigDecimal.ZERO : initialBalance;
        return repository.save(new Wallet(owner, start.setScale(2, RoundingMode.HALF_UP)));
    }

    /** Admin sees every wallet; a normal user sees only their own. */
    @Transactional(readOnly = true)
    public List<Wallet> list(Authentication auth) {
        if (isAdmin(auth)) {
            return repository.findAll();
        }
        return repository.findByOwnerUsername(auth.getName()).map(List::of).orElse(List.of());
    }

    @Transactional(readOnly = true)
    public Wallet getById(Long id, Authentication auth) {
        Wallet wallet = find(id);
        assertOwnerOrAdmin(wallet, auth);
        return wallet;
    }

    @Transactional(readOnly = true)
    public Wallet getByOwner(String username, Authentication auth) {
        Wallet wallet = repository.findByOwnerUsername(username)
                .orElseThrow(() -> new WalletNotFoundException("No wallet for user " + username));
        assertOwnerOrAdmin(wallet, auth);
        return wallet;
    }

    /** Balance-free lookup, open to any authenticated user (used to resolve a transfer receiver). */
    @Transactional(readOnly = true)
    public Wallet lookup(String username) {
        return repository.findByOwnerUsername(username)
                .orElseThrow(() -> new WalletNotFoundException("No wallet for user " + username));
    }

    @Transactional
    public Wallet updateStatus(Long id, WalletStatus status, Authentication auth) {
        Wallet wallet = find(id);
        assertOwnerOrAdmin(wallet, auth);
        wallet.setStatus(status);
        return repository.save(wallet);
    }

    @Transactional
    public void delete(Long id, Authentication auth) {
        Wallet wallet = find(id);
        assertOwnerOrAdmin(wallet, auth);
        if (wallet.getBalance().compareTo(BigDecimal.ZERO) != 0) {
            throw new IllegalStateException("Wallet balance must be zero before the wallet can be deleted");
        }
        repository.delete(wallet);
    }

    // ------------------------------------------------------ money movement

    /** Any authenticated caller may credit (top-up, or the receiving side of a transfer). */
    @Transactional
    public Wallet credit(Long id, BigDecimal amount) {
        Wallet wallet = findForUpdate(id);
        assertActive(wallet);
        wallet.setBalance(wallet.getBalance().add(amount));
        return repository.save(wallet);
    }

    /** Only the owner (or an admin) may take money out of a wallet. */
    @Transactional
    public Wallet debit(Long id, BigDecimal amount, Authentication auth) {
        Wallet wallet = findForUpdate(id);
        assertOwnerOrAdmin(wallet, auth);
        assertActive(wallet);
        if (wallet.getBalance().compareTo(amount) < 0) {
            throw new InsufficientFundsException("Insufficient balance: available "
                    + wallet.getBalance() + ", requested " + amount);
        }
        wallet.setBalance(wallet.getBalance().subtract(amount));
        return repository.save(wallet);
    }

    // --------------------------------------------------------------- helpers

    private Wallet find(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new WalletNotFoundException("Wallet not found with id: " + id));
    }

    private Wallet findForUpdate(Long id) {
        return repository.findByIdForUpdate(id)
                .orElseThrow(() -> new WalletNotFoundException("Wallet not found with id: " + id));
    }

    private void assertActive(Wallet wallet) {
        if (wallet.getStatus() != WalletStatus.ACTIVE) {
            throw new IllegalStateException("Wallet " + wallet.getId() + " is " + wallet.getStatus());
        }
    }

    private void assertOwnerOrAdmin(Wallet wallet, Authentication auth) {
        if (!isAdmin(auth) && !wallet.getOwnerUsername().equals(auth.getName())) {
            throw new AccessDeniedException("You can only access your own wallet");
        }
    }

    private boolean isAdmin(Authentication auth) {
        return auth.getAuthorities().stream().anyMatch(a -> "ROLE_ADMIN".equals(a.getAuthority()));
    }
}
