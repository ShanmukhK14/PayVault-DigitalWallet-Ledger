package com.payvault.walletservice.config;

import org.springframework.stereotype.Component;

import java.net.InetAddress;

/** Tells a caller which running copy of wallet-service answered. */
@Component
public class InstanceInfo {

    private final String host;

    public InstanceInfo() {
        String h;
        try {
            h = InetAddress.getLocalHost().getHostName();
        } catch (Exception e) {
            h = "unknown-host";
        }
        this.host = h;
    }

    public String getHost() {
        return host;
    }
}
