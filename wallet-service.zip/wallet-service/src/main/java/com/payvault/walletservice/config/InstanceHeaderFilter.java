package com.payvault.walletservice.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/** Adds "X-Served-By: host:port" to every response so load balancing is visible in Postman. */
@Component
public class InstanceHeaderFilter extends OncePerRequestFilter {

    private final InstanceInfo instanceInfo;

    public InstanceHeaderFilter(InstanceInfo instanceInfo) {
        this.instanceInfo = instanceInfo;
    }

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request,
                                     @NonNull HttpServletResponse response,
                                     @NonNull FilterChain filterChain) throws ServletException, IOException {
        response.setHeader("X-Served-By", instanceInfo.getHost() + ":" + request.getLocalPort());
        filterChain.doFilter(request, response);
    }
}
