package com.payvault.walletservice.dto;

import com.payvault.walletservice.entity.WalletStatus;
import jakarta.validation.constraints.NotNull;

public class UpdateWalletRequest {

    @NotNull(message = "status is required (ACTIVE or SUSPENDED)")
    private WalletStatus status;

    public WalletStatus getStatus() { return status; }
    public void setStatus(WalletStatus status) { this.status = status; }
}
