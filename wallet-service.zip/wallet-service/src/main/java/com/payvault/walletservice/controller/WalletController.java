package com.payvault.walletservice.controller;

import com.payvault.walletservice.config.InstanceInfo;
import com.payvault.walletservice.dto.*;
import com.payvault.walletservice.entity.Wallet;
import com.payvault.walletservice.service.WalletService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/wallets")
public class WalletController {

    private final WalletService service;
    private final InstanceInfo instanceInfo;

    public WalletController(WalletService service, InstanceInfo instanceInfo) {
        this.service = service;
        this.instanceInfo = instanceInfo;
    }

    // ---- Create ----
    @PostMapping
    public ResponseEntity<WalletResponse> create(@Valid @RequestBody(required = false) CreateWalletRequest request,
                                                 Authentication auth) {
        Wallet wallet = service.create(auth, request == null ? null : request.getInitialBalance());
        return ResponseEntity.status(HttpStatus.CREATED).body(WalletResponse.from(wallet));
    }

    // ---- Read ----
    @GetMapping
    public List<WalletResponse> list(Authentication auth) {
        return service.list(auth).stream().map(WalletResponse::from).collect(Collectors.toList());
    }

    @GetMapping("/me")
    public WalletResponse me(Authentication auth) {
        return WalletResponse.from(service.getByOwner(auth.getName(), auth));
    }

    @GetMapping("/{id}")
    public WalletResponse getById(@PathVariable Long id, Authentication auth) {
        return WalletResponse.from(service.getById(id, auth));
    }

    @GetMapping("/owner/{username}")
    public WalletResponse getByOwner(@PathVariable String username, Authentication auth) {
        return WalletResponse.from(service.getByOwner(username, auth));
    }

    @GetMapping("/lookup/{username}")
    public WalletLookupResponse lookup(@PathVariable String username) {
        return WalletLookupResponse.from(service.lookup(username));
    }

    // ---- Update ----
    @PutMapping("/{id}")
    public WalletResponse update(@PathVariable Long id,
                                 @Valid @RequestBody UpdateWalletRequest request,
                                 Authentication auth) {
        return WalletResponse.from(service.updateStatus(id, request.getStatus(), auth));
    }

    // ---- Delete ----
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id, Authentication auth) {
        service.delete(id, auth);
        return ResponseEntity.noContent().build();
    }

    // ---- Money movement ----
    @PostMapping("/{id}/credit")
    public WalletResponse credit(@PathVariable Long id, @Valid @RequestBody AmountRequest request) {
        return WalletResponse.from(service.credit(id, request.getAmount()));
    }

    @PostMapping("/{id}/debit")
    public WalletResponse debit(@PathVariable Long id,
                                @Valid @RequestBody AmountRequest request,
                                Authentication auth) {
        return WalletResponse.from(service.debit(id, request.getAmount(), auth));
    }

    // ---- Load-balancing demo ----
    @GetMapping("/instance")
    public Map<String, Object> instance(HttpServletRequest request) {
        Map<String, Object> info = new LinkedHashMap<>();
        info.put("service", "WALLET-SERVICE");
        info.put("host", instanceInfo.getHost());
        info.put("port", request.getLocalPort());
        return info;
    }
}
