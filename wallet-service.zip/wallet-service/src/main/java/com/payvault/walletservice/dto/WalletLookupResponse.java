package com.payvault.walletservice.dto;

import com.payvault.walletservice.entity.Wallet;
import com.payvault.walletservice.entity.WalletStatus;

/**
 * Safe, balance-free view used by Transaction Service to find the receiver's
 * wallet by username. Any authenticated user may call lookup; only the owner
 * (or an admin) can see a balance.
 */
public class WalletLookupResponse {

    private Long walletId;
    private String ownerUsername;
    private WalletStatus status;

    public static WalletLookupResponse from(Wallet w) {
        WalletLookupResponse r = new WalletLookupResponse();
        r.walletId = w.getId();
        r.ownerUsername = w.getOwnerUsername();
        r.status = w.getStatus();
        return r;
    }

    public Long getWalletId() { return walletId; }
    public String getOwnerUsername() { return ownerUsername; }
    public WalletStatus getStatus() { return status; }
}
