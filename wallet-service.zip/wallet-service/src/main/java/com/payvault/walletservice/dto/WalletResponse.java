package com.payvault.walletservice.dto;

import com.payvault.walletservice.entity.Wallet;
import com.payvault.walletservice.entity.WalletStatus;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class WalletResponse {

    private Long id;
    private String ownerUsername;
    private BigDecimal balance;
    private String currency;
    private WalletStatus status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public static WalletResponse from(Wallet w) {
        WalletResponse r = new WalletResponse();
        r.id = w.getId();
        r.ownerUsername = w.getOwnerUsername();
        r.balance = w.getBalance();
        r.currency = w.getCurrency();
        r.status = w.getStatus();
        r.createdAt = w.getCreatedAt();
        r.updatedAt = w.getUpdatedAt();
        return r;
    }

    public Long getId() { return id; }
    public String getOwnerUsername() { return ownerUsername; }
    public BigDecimal getBalance() { return balance; }
    public String getCurrency() { return currency; }
    public WalletStatus getStatus() { return status; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
}
