package com.payvault.walletservice.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;

import java.math.BigDecimal;

public class CreateWalletRequest {

    /** Optional opening balance (demo convenience). Defaults to 0. */
    @DecimalMin(value = "0.00", message = "initialBalance cannot be negative")
    @Digits(integer = 15, fraction = 2, message = "initialBalance allows at most 2 decimal places")
    private BigDecimal initialBalance;

    public BigDecimal getInitialBalance() { return initialBalance; }
    public void setInitialBalance(BigDecimal initialBalance) { this.initialBalance = initialBalance; }
}
