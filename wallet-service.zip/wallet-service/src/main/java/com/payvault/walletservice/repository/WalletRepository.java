package com.payvault.walletservice.repository;

import com.payvault.walletservice.entity.Wallet;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface WalletRepository extends JpaRepository<Wallet, Long> {

    Optional<Wallet> findByOwnerUsername(String ownerUsername);

    boolean existsByOwnerUsername(String ownerUsername);

    /**
     * Row-level lock (SELECT ... FOR UPDATE). Two concurrent debits on the same
     * wallet queue up instead of both reading the old balance -> no lost updates.
     */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select w from Wallet w where w.id = :id")
    Optional<Wallet> findByIdForUpdate(@Param("id") Long id);
}
