package com.payvault.walletservice.entity;

public enum WalletStatus {
    ACTIVE, SUSPENDED
}
