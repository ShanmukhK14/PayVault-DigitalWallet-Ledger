# wallet-service (port 8083, DB: wallet_db)

## 1. One-time setup
1. pgAdmin -> Query Tool on the server -> run:  `CREATE DATABASE wallet_db;`
2. Copy this whole `wallet-service` folder into the repo root (next to `auth-service`, `user-service`...).
3. Add the route below to `api-gateway/src/main/resources/application.yml`
   (under `spring.cloud.gateway.routes`, same indentation as the other routes), then restart the gateway:

```yaml
        - id: wallet-service-route
          uri: lb://WALLET-SERVICE
          predicates:
            - Path=/api/wallets/**
          filters:
            - AuthenticationFilter
```

4. Import as Existing Maven Project, run: discovery-server -> auth-service -> user-service -> wallet-service -> api-gateway.

## 2. Endpoints (all via the gateway, port 8080, all need `Authorization: Bearer {{token}}`)

| Method | URL | Who | Body |
|---|---|---|---|
| POST | /api/wallets | any user (wallet is created for the token's user) | `{"initialBalance": 1000}` (optional) |
| GET | /api/wallets | user: own wallet only / ADMIN: all | |
| GET | /api/wallets/me | owner | |
| GET | /api/wallets/{id} | owner or ADMIN | |
| GET | /api/wallets/owner/{username} | owner or ADMIN | |
| GET | /api/wallets/lookup/{username} | any user (no balance shown) | |
| PUT | /api/wallets/{id} | owner or ADMIN | `{"status": "SUSPENDED"}` or `ACTIVE` |
| DELETE | /api/wallets/{id} | owner or ADMIN, balance must be 0 | |
| POST | /api/wallets/{id}/credit | any user | `{"amount": 250.50}` |
| POST | /api/wallets/{id}/debit | owner or ADMIN | `{"amount": 100}` |
| GET | /api/wallets/instance | any user | which copy answered |

Errors: 400 bad input, 401 no/invalid token, 403 not your wallet, 404 not found,
409 rule conflict (duplicate wallet, suspended wallet, delete with balance), 422 insufficient funds.

## 3. Load-balancing demo
1. In STS: Run Configurations -> wallet-service -> Arguments -> VM arguments: `-Dserver.port=8084`, run a second copy
   (keep the first on 8083).
2. Eureka (http://localhost:8761) should now list two WALLET-SERVICE instances.
3. In Postman call `GET {{base_url}}/api/wallets/instance` several times. The JSON `port` (and the
   `X-Served-By` response header) alternates between 8083 and 8084.

## 4. Making an admin (for the ADMIN checks)
Register a user normally, then in pgAdmin on `auth_db`:
`UPDATE users SET role = 'ADMIN' WHERE username = 'someone';` and log in again to get a new token.

## 5. Tests
`mvn test` inside this folder (9 unit tests, no database needed).

## 6. Dockerfile
Included as the template for the Docker task. It has not been build-tested here; run
`docker build -t wallet-service .` once to confirm.
