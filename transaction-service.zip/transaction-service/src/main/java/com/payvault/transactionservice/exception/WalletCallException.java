package com.payvault.transactionservice.exception;

/** Something went wrong while talking to wallet-service. Carries the HTTP status it answered with. */
public class WalletCallException extends RuntimeException {

    private final int status;

    public WalletCallException(int status, String message) {
        super(message);
        this.status = status;
    }

    public int getStatus() {
        return status;
    }
}
