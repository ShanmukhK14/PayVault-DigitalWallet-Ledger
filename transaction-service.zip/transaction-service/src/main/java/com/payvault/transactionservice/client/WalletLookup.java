package com.payvault.transactionservice.client;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** wallet-service's balance-free lookup answer: just id, owner and status. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class WalletLookup {

    private Long walletId;
    private String ownerUsername;
    private String status;

    public Long getWalletId() { return walletId; }
    public void setWalletId(Long walletId) { this.walletId = walletId; }

    public String getOwnerUsername() { return ownerUsername; }
    public void setOwnerUsername(String ownerUsername) { this.ownerUsername = ownerUsername; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
