package com.payvault.transactionservice.entity;

public enum TransactionStatus {
    PENDING,        // saved, money not moved yet
    SUCCESS,        // sender debited and receiver credited
    FAILED,         // nothing moved (for example insufficient balance)
    REVERSED,       // receiver credit failed, sender was refunded
    NEEDS_REVIEW    // credit AND refund failed: a human must check
}
