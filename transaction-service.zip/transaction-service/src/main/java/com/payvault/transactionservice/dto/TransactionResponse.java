package com.payvault.transactionservice.dto;

import com.payvault.transactionservice.entity.TransactionRecord;
import com.payvault.transactionservice.entity.TransactionStatus;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class TransactionResponse {

    private Long id;
    private String referenceId;
    private String senderUsername;
    private String receiverUsername;
    private BigDecimal amount;
    private TransactionStatus status;
    private String failureReason;
    private String description;
    private LocalDateTime createdAt;

    public static TransactionResponse from(TransactionRecord t) {
        TransactionResponse r = new TransactionResponse();
        r.id = t.getId();
        r.referenceId = t.getReferenceId();
        r.senderUsername = t.getSenderUsername();
        r.receiverUsername = t.getReceiverUsername();
        r.amount = t.getAmount();
        r.status = t.getStatus();
        r.failureReason = t.getFailureReason();
        r.description = t.getDescription();
        r.createdAt = t.getCreatedAt();
        return r;
    }

    public Long getId() { return id; }
    public String getReferenceId() { return referenceId; }
    public String getSenderUsername() { return senderUsername; }
    public String getReceiverUsername() { return receiverUsername; }
    public BigDecimal getAmount() { return amount; }
    public TransactionStatus getStatus() { return status; }
    public String getFailureReason() { return failureReason; }
    public String getDescription() { return description; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
