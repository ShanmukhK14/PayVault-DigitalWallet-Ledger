package com.payvault.transactionservice.client;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.math.BigDecimal;

/** The part of wallet-service's WalletResponse that we need. */
@JsonIgnoreProperties(ignoreUnknown = true)
public class WalletView {

    private Long id;
    private String ownerUsername;
    private BigDecimal balance;
    private String status;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getOwnerUsername() { return ownerUsername; }
    public void setOwnerUsername(String ownerUsername) { this.ownerUsername = ownerUsername; }

    public BigDecimal getBalance() { return balance; }
    public void setBalance(BigDecimal balance) { this.balance = balance; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
