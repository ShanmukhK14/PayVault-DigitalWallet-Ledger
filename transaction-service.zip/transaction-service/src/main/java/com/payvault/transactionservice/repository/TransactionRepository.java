package com.payvault.transactionservice.repository;

import com.payvault.transactionservice.entity.TransactionRecord;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TransactionRepository extends JpaRepository<TransactionRecord, Long> {

    List<TransactionRecord> findBySenderUsernameOrReceiverUsernameOrderByCreatedAtDesc(String sender, String receiver);
}
