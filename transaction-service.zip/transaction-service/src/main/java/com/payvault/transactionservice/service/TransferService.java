package com.payvault.transactionservice.service;

import com.payvault.transactionservice.client.WalletClient;
import com.payvault.transactionservice.client.WalletLookup;
import com.payvault.transactionservice.client.WalletView;
import com.payvault.transactionservice.entity.TransactionRecord;
import com.payvault.transactionservice.entity.TransactionStatus;
import com.payvault.transactionservice.exception.TransactionNotFoundException;
import com.payvault.transactionservice.exception.WalletCallException;
import com.payvault.transactionservice.repository.TransactionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Sort;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

/**
 * Orchestrates a transfer:
 *   1. find both wallets
 *   2. save the transaction as PENDING
 *   3. debit the sender
 *   4. credit the receiver
 *   5. if step 4 fails, refund the sender (compensation) so no money is lost
 *
 * Note: this class is deliberately NOT @Transactional. The money lives in
 * wallet-service's database, so one local database transaction cannot cover it.
 * Each save below is its own small commit, which keeps the ledger honest even when a later step fails.
 */
@Service
public class TransferService {

    private static final Logger log = LoggerFactory.getLogger(TransferService.class);

    private final TransactionRepository repository;
    private final WalletClient walletClient;

    public TransferService(TransactionRepository repository, WalletClient walletClient) {
        this.repository = repository;
        this.walletClient = walletClient;
    }

    public TransactionRecord transfer(String sender, String authHeader, String receiver,
                                      BigDecimal amount, String description) {

        if (sender.equalsIgnoreCase(receiver)) {
            throw new IllegalArgumentException("You cannot transfer money to yourself");
        }

        // 1. find both wallets
        WalletView senderWallet = findSenderWallet(authHeader);
        WalletLookup receiverWallet = findReceiverWallet(receiver, authHeader);
        if (!"ACTIVE".equals(receiverWallet.getStatus())) {
            throw new IllegalStateException("The receiver's wallet is not active");
        }

        // 2. write the ledger row first, so even a crash leaves a trace
        TransactionRecord txn = repository.save(new TransactionRecord(
                sender, receiver, senderWallet.getId(), receiverWallet.getWalletId(), amount, description));
        String ref = txn.getReferenceId();

        // 3. take the money from the sender
        try {
            walletClient.debit(senderWallet.getId(), amount, ref, authHeader);
        } catch (WalletCallException e) {
            return finish(txn, TransactionStatus.FAILED, "Could not debit sender: " + e.getMessage());
        }

        // 4. give it to the receiver
        try {
            walletClient.credit(receiverWallet.getWalletId(), amount, ref, authHeader);
        } catch (WalletCallException creditError) {
            log.warn("Credit failed for {}: {}. Refunding sender.", ref, creditError.getMessage());

            // 5. compensation: put the money back
            try {
                walletClient.credit(senderWallet.getId(), amount, ref + "-refund", authHeader);
                return finish(txn, TransactionStatus.REVERSED,
                        "Credit to receiver failed (" + creditError.getMessage() + "). Sender was refunded.");
            } catch (WalletCallException refundError) {
                log.error("REFUND FAILED for {}: {}", ref, refundError.getMessage());
                return finish(txn, TransactionStatus.NEEDS_REVIEW,
                        "Credit failed (" + creditError.getMessage() + ") and refund failed ("
                                + refundError.getMessage() + "). Manual check needed.");
            }
        }

        return finish(txn, TransactionStatus.SUCCESS, null);
    }

    /** Admin sees all; everyone else sees transactions they sent or received. */
    public List<TransactionRecord> list(Authentication auth) {
        if (isAdmin(auth)) {
            return repository.findAll(Sort.by(Sort.Direction.DESC, "createdAt"));
        }
        return repository.findBySenderUsernameOrReceiverUsernameOrderByCreatedAtDesc(auth.getName(), auth.getName());
    }

    public TransactionRecord getById(Long id, Authentication auth) {
        TransactionRecord txn = repository.findById(id)
                .orElseThrow(() -> new TransactionNotFoundException("Transaction not found with id: " + id));
        boolean involved = auth.getName().equals(txn.getSenderUsername())
                || auth.getName().equals(txn.getReceiverUsername());
        if (!involved && !isAdmin(auth)) {
            throw new AccessDeniedException("You can only view your own transactions");
        }
        return txn;
    }

    // ------------------------------------------------------------ helpers

    private WalletView findSenderWallet(String authHeader) {
        try {
            return walletClient.myWallet(authHeader);
        } catch (WalletCallException e) {
            if (e.getStatus() == 404) {
                throw new WalletCallException(404, "You do not have a wallet yet. Create one first.");
            }
            throw e;
        }
    }

    private WalletLookup findReceiverWallet(String receiver, String authHeader) {
        try {
            return walletClient.lookup(receiver, authHeader);
        } catch (WalletCallException e) {
            if (e.getStatus() == 404) {
                throw new WalletCallException(404, "Receiver '" + receiver + "' has no wallet");
            }
            throw e;
        }
    }

    private TransactionRecord finish(TransactionRecord txn, TransactionStatus status, String reason) {
        txn.setStatus(status);
        txn.setFailureReason(reason);
        return repository.save(txn);
    }

    private boolean isAdmin(Authentication auth) {
        return auth.getAuthorities().stream().anyMatch(a -> "ROLE_ADMIN".equals(a.getAuthority()));
    }
}
