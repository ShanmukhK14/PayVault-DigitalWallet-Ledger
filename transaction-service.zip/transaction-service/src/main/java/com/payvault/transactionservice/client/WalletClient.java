package com.payvault.transactionservice.client;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.payvault.transactionservice.exception.WalletCallException;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Talks to wallet-service. Every call passes the caller's own JWT along, so
 * wallet-service applies its normal checks (you can only debit YOUR wallet).
 */
@Component
public class WalletClient {

    private static final String BASE = "http://WALLET-SERVICE/api/wallets";

    private final RestTemplate restTemplate;
    private final ObjectMapper mapper = new ObjectMapper();

    public WalletClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    /** The logged-in user's own wallet. */
    public WalletView myWallet(String authHeader) {
        return call(BASE + "/me", HttpMethod.GET, null, authHeader, WalletView.class);
    }

    /** Find another user's wallet id (no balance is revealed). */
    public WalletLookup lookup(String username, String authHeader) {
        return call(BASE + "/lookup/{username}", HttpMethod.GET, null, authHeader, WalletLookup.class, username);
    }

    public void debit(Long walletId, BigDecimal amount, String reference, String authHeader) {
        call(BASE + "/{id}/debit", HttpMethod.POST, body(amount, reference), authHeader, String.class, walletId);
    }

    public void credit(Long walletId, BigDecimal amount, String reference, String authHeader) {
        call(BASE + "/{id}/credit", HttpMethod.POST, body(amount, reference), authHeader, String.class, walletId);
    }

    private Map<String, Object> body(BigDecimal amount, String reference) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("amount", amount);
        map.put("reference", reference);
        return map;
    }

    private <T> T call(String url, HttpMethod method, Object body, String authHeader,
                       Class<T> responseType, Object... uriVariables) {
        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.AUTHORIZATION, authHeader);
        headers.setContentType(MediaType.APPLICATION_JSON);
        try {
            return restTemplate.exchange(url, method, new HttpEntity<Object>(body, headers),
                    responseType, uriVariables).getBody();
        } catch (HttpStatusCodeException e) {
            // wallet-service answered with an error (400, 403, 404, 409, 422 ...)
            throw new WalletCallException(e.getStatusCode().value(), readMessage(e));
        } catch (RestClientException e) {
            // wallet-service is down or too slow
            throw new WalletCallException(503, "Wallet service is not reachable right now");
        }
    }

    private String readMessage(HttpStatusCodeException e) {
        try {
            JsonNode node = mapper.readTree(e.getResponseBodyAsString());
            if (node.hasNonNull("message")) {
                return node.get("message").asText();
            }
        } catch (Exception ignored) {
            // body was empty or not JSON
        }
        return "Wallet service answered with status " + e.getStatusCode().value();
    }
}
