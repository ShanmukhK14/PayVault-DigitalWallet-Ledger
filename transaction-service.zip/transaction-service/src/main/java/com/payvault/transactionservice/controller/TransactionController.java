package com.payvault.transactionservice.controller;

import com.payvault.transactionservice.dto.TransactionResponse;
import com.payvault.transactionservice.dto.TransferRequest;
import com.payvault.transactionservice.entity.TransactionRecord;
import com.payvault.transactionservice.entity.TransactionStatus;
import com.payvault.transactionservice.service.TransferService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {

    private final TransferService service;

    public TransactionController(TransferService service) {
        this.service = service;
    }

    /** 201 when the money moved, 422 (with the saved record explaining why) when it did not. */
    @PostMapping("/transfer")
    public ResponseEntity<TransactionResponse> transfer(@Valid @RequestBody TransferRequest request,
                                                        Authentication auth,
                                                        @RequestHeader("Authorization") String authHeader) {
        TransactionRecord txn = service.transfer(auth.getName(), authHeader,
                request.getReceiverUsername().trim(), request.getAmount(), request.getDescription());

        HttpStatus status = txn.getStatus() == TransactionStatus.SUCCESS
                ? HttpStatus.CREATED : HttpStatus.UNPROCESSABLE_ENTITY;
        return ResponseEntity.status(status).body(TransactionResponse.from(txn));
    }

    @GetMapping
    public List<TransactionResponse> list(Authentication auth) {
        return service.list(auth).stream().map(TransactionResponse::from).collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public TransactionResponse getById(@PathVariable Long id, Authentication auth) {
        return TransactionResponse.from(service.getById(id, auth));
    }
}
