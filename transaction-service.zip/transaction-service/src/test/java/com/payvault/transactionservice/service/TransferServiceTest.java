package com.payvault.transactionservice.service;

import com.payvault.transactionservice.client.WalletClient;
import com.payvault.transactionservice.client.WalletLookup;
import com.payvault.transactionservice.client.WalletView;
import com.payvault.transactionservice.entity.TransactionRecord;
import com.payvault.transactionservice.entity.TransactionStatus;
import com.payvault.transactionservice.exception.WalletCallException;
import com.payvault.transactionservice.repository.TransactionRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/** Unit tests for the transfer flow. wallet-service and the database are mocked. */
@ExtendWith(MockitoExtension.class)
class TransferServiceTest {

    private static final String AUTH = "Bearer test-token";
    private static final BigDecimal AMOUNT = new BigDecimal("100.00");

    @Mock
    private TransactionRepository repository;

    @Mock
    private WalletClient walletClient;

    @InjectMocks
    private TransferService service;

    /** alice has wallet 1, bob has wallet 2 and it is ACTIVE. */
    private void givenBothWalletsExist() {
        WalletView aliceWallet = new WalletView();
        aliceWallet.setId(1L);
        aliceWallet.setOwnerUsername("alice");

        WalletLookup bobWallet = new WalletLookup();
        bobWallet.setWalletId(2L);
        bobWallet.setOwnerUsername("bob");
        bobWallet.setStatus("ACTIVE");

        when(walletClient.myWallet(AUTH)).thenReturn(aliceWallet);
        when(walletClient.lookup("bob", AUTH)).thenReturn(bobWallet);
        when(repository.save(any(TransactionRecord.class))).thenAnswer(inv -> inv.getArgument(0));
    }

    @Test
    void transfer_success_debitsSenderAndCreditsReceiver() {
        givenBothWalletsExist();

        TransactionRecord result = service.transfer("alice", AUTH, "bob", AMOUNT, "lunch");

        assertEquals(TransactionStatus.SUCCESS, result.getStatus());
        verify(walletClient).debit(eq(1L), eq(AMOUNT), anyString(), eq(AUTH));
        verify(walletClient).credit(eq(2L), eq(AMOUNT), anyString(), eq(AUTH));
    }

    @Test
    void transfer_insufficientFunds_isFailedAndReceiverIsNeverCredited() {
        givenBothWalletsExist();
        doThrow(new WalletCallException(422, "Insufficient balance"))
                .when(walletClient).debit(eq(1L), any(BigDecimal.class), anyString(), eq(AUTH));

        TransactionRecord result = service.transfer("alice", AUTH, "bob", AMOUNT, null);

        assertEquals(TransactionStatus.FAILED, result.getStatus());
        verify(walletClient, never()).credit(any(), any(), anyString(), anyString());
    }

    @Test
    void transfer_whenCreditFails_senderIsRefunded() {
        givenBothWalletsExist();
        doThrow(new WalletCallException(503, "Wallet service is not reachable right now"))
                .when(walletClient).credit(eq(2L), any(BigDecimal.class), anyString(), eq(AUTH));

        TransactionRecord result = service.transfer("alice", AUTH, "bob", AMOUNT, null);

        assertEquals(TransactionStatus.REVERSED, result.getStatus());
        // the refund goes back to alice's wallet (id 1), reference ends with -refund
        verify(walletClient).credit(eq(1L), eq(AMOUNT), org.mockito.ArgumentMatchers.endsWith("-refund"), eq(AUTH));
    }

    @Test
    void transfer_whenCreditAndRefundBothFail_needsManualReview() {
        givenBothWalletsExist();
        doThrow(new WalletCallException(503, "down"))
                .when(walletClient).credit(eq(2L), any(BigDecimal.class), anyString(), eq(AUTH));
        doThrow(new WalletCallException(503, "still down"))
                .when(walletClient).credit(eq(1L), any(BigDecimal.class), anyString(), eq(AUTH));

        TransactionRecord result = service.transfer("alice", AUTH, "bob", AMOUNT, null);

        assertEquals(TransactionStatus.NEEDS_REVIEW, result.getStatus());
    }

    @Test
    void transfer_toYourself_isRejected() {
        assertThrows(IllegalArgumentException.class,
                () -> service.transfer("alice", AUTH, "Alice", AMOUNT, null));

        verify(repository, never()).save(any(TransactionRecord.class));
    }
}
