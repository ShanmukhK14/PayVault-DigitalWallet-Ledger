# transaction-service (port 8085, DB: transaction_db)

What it does: moves money from one user to another.
It asks wallet-service to take the money from the sender, then give it to the receiver.
If giving fails, it refunds the sender, so money is never lost.

Setup (same as wallet-service):
1. pgAdmin: create database `transaction_db`
2. Put your PostgreSQL password in src/main/resources/application.yml (the `password:` line)
3. Add the gateway route for /api/transactions/** and restart the gateway
4. Run it after Eureka and wallet-service are running

Endpoints (via gateway, port 8080, Bearer token needed):
- POST /api/transactions/transfer   body: {"receiverUsername":"ravi","amount":100,"description":"lunch"}
- GET  /api/transactions            my sent and received transactions
- GET  /api/transactions/{id}       one transaction (only if you are the sender or receiver)

Statuses: SUCCESS, FAILED (nothing moved), REVERSED (refunded), NEEDS_REVIEW (rare)
The ledger is never edited or deleted on purpose: history must stay traceable.

Tests: `mvn test` (5 unit tests, no database needed).
